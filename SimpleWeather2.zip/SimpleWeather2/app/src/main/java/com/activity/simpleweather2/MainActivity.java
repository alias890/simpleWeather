package com.activity.simpleweather2;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.os.AsyncTask;
import android.os.Bundle;

import java.io.IOException;
import java.net.URL;

public class MainActivity extends AppCompatActivity {

    TideFragment tideFragment;
    WeatherFragment weatherFragment;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        tideFragment = new TideFragment();
        weatherFragment = new WeatherFragment();
        //in main activity xml, find weather fragment container - call the fragment
        FragmentManager manager = getSupportFragmentManager();
        FragmentTransaction transaction = manager.beginTransaction();
        transaction.replace(R.id.weather_fragment_container,weatherFragment);//replace weather fragment container with weather fragment.
        transaction.replace(R.id.tide_fragment_container,tideFragment);//replace tide fragment container with tide fragment
        transaction.commit();

    }


}