package com.activity.simpleweather2;

import android.net.Uri;
import android.preference.PreferenceFragment;
import android.util.Log;

import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Scanner;

public class NetworkUtil

{
    public static final String BASE_URL ="https://dataservice.accuweather.com/forecasts/v1/daily/5day/305605";
    public static final String  METRIC_VALUE ="true";
    public static final String METRIC_PARAM="metric";
    public static final String API_KEY="djhMRaqAJwAt5mMcPk9wCmStYiH8kLj2";
    public static final String API_PARAM="apikey";//check api reference
    public static final String TAG ="ourURL";
     //URI- is an identifier for a specific resource eg. a page, book - (what it is)
    //URL- is a special type of identifier, tells you how to access it eg. HTTPs, FTP - (how to get there)

    public static URL buildURLForWeather()
    {
        //first build uri
        Uri uri = Uri.parse(BASE_URL).buildUpon()
                .appendQueryParameter(API_PARAM,API_KEY)
                .appendQueryParameter(METRIC_PARAM,METRIC_VALUE)
                .build();

        URL url = null;// set to null because return value throws exception
    //converts uri to url
        try
        {
            url = new URL(uri.toString());
        } catch (MalformedURLException e)
        {
            e.printStackTrace();
        }
        Log.i(TAG, "buildURLForWeather: "+url);//displays url in logcat

        return url;
    }

    //method that connects to api, gets response
    public static String getResponse(URL url) throws IOException
    {
        HttpURLConnection httpURLConnection = (HttpURLConnection)url.openConnection();
        try
        {

            InputStream in = httpURLConnection.getInputStream();
            Scanner scanner = new Scanner(in);
            scanner.useDelimiter("//A");// A means it is a start of a string
            boolean scannerHasInput = scanner.hasNext();

            if(scannerHasInput)
            {
                return scanner.next();

            }
            else
                {
                        return null;

            }
        }
        finally
        {
            httpURLConnection.disconnect();
        }
        //continue on fragments:
        //https://www.youtube.com/watch?v=dP6rTP_cUfg&list=PL480DYS-b_kf-pheFMX1W_-YmnMpg4Gs7&index=6

    }

}
